module VisualRecognitionClassify
  class Classify
    API_URL = 'https://gateway-a.watsonplatform.net/visual-recognition/api/v3/classifiers?'.freeze

    def upload(positive_images_dir, negative_images_dir, name, version = nil)
      potitive_zip = zip(positive_images_dir)
      negative_zip = zip(negative_images_dir)

      sess = Patron::Session.new
      sess.timeout = 10
      # sess.base_url = "http://myserver.com:9900"
      data = {
        positive_example => "@#{positive_zip}",
        negative_example => "@#{negative_zip}",
        'name' => name
      }
      sess.post(api_url(version), data)

    end

    def list
    end

    def status(classify_id)
    end

    private

    def positive_example(name)
      "#{name}_positive_examples"
    end

    def negative_example
      "negative_examples"
    end

    def api_url(version)
      @vesion = Time.now.strftime('%Y-%m-%d-01') if @version.nil?
      "#{API_URL}api_key=#{api_key}&version=#{version}"
    end

    def api_key
      ENV['VISUAL_RECOGNITION_API_KEY'] || ''
    end

    def version
      Time.zone.now.strftime("%Y-%m-%d-#{version_count}")
    end

    def version_count
      @version_count = @version_count&.next || 1
      sprintf("%02d", @version_count)
    end
  end
end
