require "visual_recognition_classify/version"

module VisualRecognitionClassify
  # Your code goes here...
end
